
# VietinBank eFast (UI clone)

Это учебное Flutter-приложение.
Название: VietinBank eFast  

## Сборка APK

1. Зайти на [https://codemagic.io](https://codemagic.io).
2. Создать новый проект, загрузить этот ZIP.
3. Запустить сборку под Android → APK.
4. Скачать готовый .apk и установить на телефон.
